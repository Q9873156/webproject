<?php
session_start();
session_unset();
session_destroy();
?>
<html>
<script type="text/javascript">
<!--
  location="index.php"
-->
</script>
<body bgcolor="#ffffdd">
<div style="text-align:center;"> 
<h2>已登出</h2>
</div>
</body>
</html>